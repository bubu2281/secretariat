package org.example;

public class MasterStudent extends Student{
    public MasterStudent(String name) {
        super(name);
    }
}
