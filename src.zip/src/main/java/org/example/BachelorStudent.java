package org.example;

public class BachelorStudent extends Student {
    public BachelorStudent(String name) {
        super(name);
    }
}
